chrome.extension.onMessage.addListener(function(request, sender) {
    if (request.action == "getSource") {
        if(request.source != null){
            var len = request.source.length;
        	if(len > 0) {
        		document.body.innerText = "Step1:Success!";
        	}
        	else {
                document.body.innerText = "Step1:Fail!\n Please check again.";
        	}
        }
        else {
                document.body.innerText = "Step1:Fail!\n Please check again.";
        }
    }
});

function onWindowLoad() {
    chrome.tabs.executeScript(null, {
        file: "getSource.js"
        }, function() {
            if (chrome.extension.lastError) {
                document.body.innerText = 'There was an error injecting script : \n' + chrome.extension.lastError.message;
            }
        });
}
window.onload = onWindowLoad;