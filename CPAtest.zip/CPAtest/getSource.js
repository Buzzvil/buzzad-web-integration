function get_source(localstorage){
    return localstorage.getItem('BuzzAd');
}

chrome.extension.sendMessage({
    action: "getSource",
    source: get_source(localStorage)
});
